//bibliotecas
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>
 
//variaveis
int idade1, idade2;
char nome1[20], nome2[20];

//algoritmo
int main(){
    setlocale(LC_ALL, "portuguese");
    
    printf("Digite o nome da primeira pessoa\n\n");
    //scanf("%c",&nome1);
    gets (nome1);
    fflush(stdin);
    
    printf("Digite a idade da primeira pessoa\n\n");
    scanf("%i",&idade1);
    fflush(stdin);
    
    printf("Digite o nome da segunda pessoa\n\n");
    //scanf("%c",&nome2);
    gets (nome2);
    fflush(stdin);
    
    printf("Digite a idade da segunda pessoa\n\n");
    scanf("%i",&idade2); 
    fflush(stdin);
    
    if(idade1==idade2){
       printf("As idades s�o iguais :)\n\n");
       }else{ if(idade1>idade2){printf("A pessoa mais velha se chama %s\n\n", nome1);
       fflush(stdin);}else{printf("A pessoa mais velha se chama %s\n\n", nome2);}} 

 

//executavel   
    system("pause");
    return(0);	
}


