#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>

float valor1, valor2,soma;
int contador;

int main(){
    setlocale(LC_ALL, "portuguese");
    
    printf("Envie os 2 valores que deseja multiplicar\n\n");
    scanf("%f",&valor1);
    scanf("%f",&valor2);
    fflush(stdin);
    system("cls");
    
    
    while(contador!=valor1){
       soma = soma+valor2;
       contador++;
       };
    
    printf("O resultado � %.2f\n\n",soma);
          
    
    
    
    
    
    system("pause");
    return(0);	
}
