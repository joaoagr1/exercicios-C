
//bibliotecas
#include <locale.h>
#include <conio.c>
 
//variaveis
int numero, resto;

//algoritmo
int main(){
    setlocale(LC_ALL, "portuguese");
    
    printf("digite um n�mero inteiro\n\n");
    scanf("%i",&numero);
    resto = (numero % 2);
    
    if (resto == 0){
       printf("O n�mero � par\n\n");         
} else {
printf("O n�mero � impar\n\n");
}
    
    	
      
 

//executaval   
    system("pause");
    return(0);	
}


