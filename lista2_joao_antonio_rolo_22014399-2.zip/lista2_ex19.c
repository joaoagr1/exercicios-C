#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>

float valor, prestacao;
int contador;


int main(){
    setlocale(LC_ALL, "portuguese");
    
    printf("Qual o valor do produto da loja Mam�o com A�ucar?\n\n");
    scanf("%f",&valor);
    fflush(stdin);
    prestacao = valor/5;
    contador = 1;
    
    while(contador<5){
                      printf("O valor da %i� presta��o � %.2f\n\n",contador, prestacao);
                      contador++;
                      }
    
    system("pause");
    return(0);	
}
