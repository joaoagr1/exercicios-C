#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>

float valor1, valor2,soma;
int contador;

int main(){
    setlocale(LC_ALL, "portuguese");
    
    printf("Envie os 2 valores que deseja multiplicar\n\n");
    scanf("%f",&valor1);
    scanf("%f",&valor2);
    fflush(stdin);
    
    for(contador = 0 ; contador < valor2; contador++){
                soma = soma + valor1;};
                
    printf("O resultado da multiplica��o � %f\n\n", soma);
    
    
    
    
    
    system("pause");
    return(0);	
}
