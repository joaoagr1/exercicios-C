//bibliotecas
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>
 
//variaveis
float salario;
char nome[20];
int idade, sexo;

//algoritmo
int main(){
    setlocale(LC_ALL, "portuguese");
    
    printf("Digite seu nome\n");
    gets(nome);
    fflush(stdin);
    
    printf("Digite sua idade\n");
    scanf("%i",&idade);
    fflush(stdin);
    
    printf("Insira seu sexo [M=1/F=2]");
    scanf("%i",&sexo);
    fflush(stdin);
    
    printf("Insira seu sal�rio");
    scanf("%f",&salario);
    fflush(stdin);
    
    if (idade>=50){
       salario=salario+(salario*35/100);}
       
    if (sexo==2 && idade<24){
       salario=salario+(salario*35/100);}
    
    if (sexo==1 && idade<27){
       salario=salario+(salario*175/1000);}
       
    if (sexo==2 && 25<idade<50){
       salario=salario+(23/100);}
       
    if (sexo==1 && 28<idade<38) {
       salario=salario+(21/100);}
       
    if (sexo==1 && 39<idade<50) {
       salario=salario+(23/100);}
       
    printf("Seu novo sal�rio � %.2f\n\n\n", salario);
    
       
       
    	
      
 

//executaval   
    system("pause");
    return(0);	
}


