#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>

int numero = 12;

int main(){
    setlocale(LC_ALL, "portuguese");
    
 
 while(numero<26){
    printf("%i\n",numero);
    numero++;}

    
     system("pause");
    return(0);	
}
