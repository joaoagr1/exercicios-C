#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>

int mes;

int main(){
    setlocale(LC_ALL, "portuguese");	
    printf("Digite seu m�s de nascimento (1-12).\n\n");
    scanf("%i",&mes);
    switch (mes) {
           case 1:
                printf("Voc� nasceu em Janeiro\n\n");
                break;
           
           case 2:
                printf("Voc� nasceu em Fevereiro\n\n");
                break;
           
           case 3:
                printf("Voc� nasceu em Mar�o\n\n");
                 break;
           
           case 4:
                printf("Voc� nasceu em Abril\n\n");
                break;
                
           case 5:
                printf("Voc� nasceu em Maio\n\n");
                break;
                
           case 6:
                printf("Voc� nasceu em Junho\n\n");
                break;
                
           case 7:
                printf("Voc� nasceu em Julho\n\n");
                break;
                
           case 8:
                printf("Voc� nasceu em Agosto\n\n");
                break;
                
           case 9:
                printf("Voc� nasceu em Setembro\n\n");
                break;
                
           
           case 10:
                printf("Voc� nasceu em Outubro\n\n");
                break;
           
           case 11:
                printf("Voc� nasceu em Novembro\n\n");
                break;
                
           case 12:
                printf("Voc� nasceu em Dezembro\n\n");
                break;
}       
           
           
    
    system("pause");
    return(0);
}   
