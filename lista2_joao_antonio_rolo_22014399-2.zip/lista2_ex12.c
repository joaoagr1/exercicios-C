#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>

float media, numero;
int cont = 1;


int main(){
    setlocale(LC_ALL, "portuguese");
    
    while(cont<11){
                   printf("Digite um n�mero [%i]   ",cont);
                   scanf("%f",&numero);
                   fflush(stdin);
                   media = media + numero;
                   cont++;
                   system("cls");
                   }
                   media = media/cont;
                   
                   printf("A m�dia dos valores digitados foi %.2f    ",media);
                   
    
    system("pause");
    return(0);
    }
