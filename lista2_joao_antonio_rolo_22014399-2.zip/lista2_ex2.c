//bibliotecas
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>
 
//variaveis
float nota1,nota2,nota3, media;

//algoritmo
int main(){
    setlocale(LC_ALL, "portuguese");
    
    printf("Digite sua primeira nota\n\n");
    scanf("%f",&nota1);
    
    printf("Digite sua segunda nota\n\n");
    scanf("%f",&nota2);
    
    printf("Digite sua terceira nota\n\n");
    scanf("%f",&nota3);
    
    media = (nota1+nota2+nota3)/3;
    
    if (media>=6){
       printf("Parab�ns, voc� foi aprovado...");
       } else{
       printf("Infelizmente voc� reprovou");}
    
    
    
    
//executaval   
    system("pause");
    return(0);	
}


