#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>

int resultado,num,x,i,z,y,cont=3, aux=1;
      
   int ehPrimo(int x){
    int i, divisores = 0;

    for(i = 1; i <= x; i++){
        if(x % i == 0)
            divisores++;
    }

    if(divisores == 2)
        return 1;// � primo
    else
        return 0; // n�o � primo
}


     int main(){
         setlocale(LC_ALL, "portuguese");
    int i;

    for(i = 1; i <= 500; i++){
        if(ehPrimo(i) == 1) // se for primo
            printf("%d, ", i); // imprime na tela
    }
    
        
 
 
 
 
    
    system("pause");
    return(0);	
}

