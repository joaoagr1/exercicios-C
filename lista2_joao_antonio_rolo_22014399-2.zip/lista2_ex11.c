#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>

float numero, media = 0;
int aux = 0;

int main(){
    setlocale(LC_ALL, "portuguese");
    
    
    do{
       printf("Digite um n�mero ");
       scanf("%f",&numero);
       fflush(stdin);
       aux++;
       media = media + numero;}
       while(aux<10);
       
       media = media/aux;
       
       printf("A m�dia desses valores � %.2f\n",media);
    
    
    
    
    
    
    
    
    
    
    system("pause");
    return(0);	




}
