//bibliotecas
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>
 
//variaveis
float numero;

//algoritmo
int main(){
    setlocale(LC_ALL, "portuguese");
    
    printf("Digite um n�mero\n\n");
    scanf("%f",&numero);
    fflush(stdin);
      
    if(50<numero && numero<100){
    printf("O n�mero est� entre 50 e 100\n\n");}
    else{printf("O n�mero n�o est� entre 50 e 100\n\n");}
 

//executaval   
    system("pause");
    return(0);	
}


