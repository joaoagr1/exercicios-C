#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>

float variavel;
int numero,cont=0, aux ;


int main(){
    setlocale(LC_ALL, "portuguese");
    
    printf("Digite um n�mero inteiro\n\n");
    scanf("%i",&numero);
    fflush(stdin);
    
    
    while(cont!=numero){
                       if(numero%cont!==0){
                       aux=aux+1;         }
          cont++;}
    
    if(aux>2){
              printf("O n�mero n�o � primo");
             }else{printf("O n�mero � primo");}
    
 
 
    
    system("pause");
    return(0);	
}
