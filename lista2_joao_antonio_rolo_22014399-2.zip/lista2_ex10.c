#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>


float numero, numerador, media;
int denominador, aux;



int main(){
    setlocale(LC_ALL, "portuguese");
    
    for (aux = 0; aux < 10; aux = aux + 1)
    {
        printf("Digite um n�mero\n\n");
        scanf("%f",&numero);
        fflush(stdin);
        
        numerador = numerador + numero;
        
        denominador++;
    }
    
    media = numerador/denominador;
    
    printf("A m�dia entre os valores digitados � %.2f",media);
    
    
        
    
    
    
    
    
    
    
    system("pause");
    return(0);	
}
    
    
