#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>

int numero1, numero2;


int main(){
    setlocale(LC_ALL, "portuguese");
 
    
       printf("Digite um n�mero inteiro e depois outro maior\n\n");
       scanf("%i",&numero1);
       fflush(stdin);
       scanf("%i",&numero2);
       fflush(stdin);
       
    

    while(numero1!=numero2){
       printf("%i-",numero1);
       numero1++;}
    
    
    system("pause");
    return(0);	
}
