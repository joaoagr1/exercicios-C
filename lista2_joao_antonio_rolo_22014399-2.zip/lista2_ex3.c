    //bibliotecas
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>
 
//variaveis
float nota1, nota2, menorNota, media, maiorNota, menorNota, novaNota, novaMedia;
int escolha, aux;

//algoritmo
int main(){
    setlocale(LC_ALL, "portuguese");
    
    printf("Quanto voc� tirou na primeira prova?\n\n");
    scanf("%f",&nota1);
    
    printf("Quanto voc� tirou na segunda prova?\n\n");
    scanf("%f",&nota2);
    
    media = (nota1 + nota2)/2;
    
    if(media>=6){
    printf("Parab�ns, voc� foi aprovado\n\n");}
    
    else{
         if(nota1>nota2){
         (menorNota=nota2)&&(maiorNota=nota1);
         }else{((menorNota=nota1) && (maiorNota=nota2));}
    printf("Sua menor nota foi %.2f\n\n", menorNota);
    printf("Deseja realizar uma prova substutiva?[1=sim][2=n�o]\n\n");
    scanf("%i",&escolha);
          if(escolha==1){
          printf("Qual sua nova nota?\n\n");
          scanf("%f",&novaNota);
          menorNota = novaNota;
          }else{printf("Como voc� n�o deseja realizar a prova substutiva devera realizar a DP\n\n");}
          novaMedia = (novaNota+maiorNota)/2;
          printf("Sua Nova m�dia � %.2f\n", novaMedia);
                      if(novaMedia>=6){
                         printf("Par�bens, com a nota da sub voc� passou de ano!!!\n\n");
                         }else{printf("Infelizmente voc� n�o conseguiu recuperar sua nota e tera que fazer DP :(\n\n");}
          
         
         
         }
    
    
    
    	
      
 
 
 
 
 

//executaval   
    system("pause");
    return(0);	
}


