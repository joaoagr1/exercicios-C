#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>


float num1, num2, media;

int main(){
    setlocale(LC_ALL, "portuguese");
    
    
     
    
    
      do{
      num1 = 0;
      num2 = 0;
      printf("Digite um valor entre 10 e 50\n\n");
      scanf("%f",&num1);
      fflush(stdin);
      system("cls");
      printf("Agora digite um valor no m�nimo 15 unidades maior que o anterior\n\n");
      scanf("%f",&num2);
      fflush(stdin);
      system("cls");
      num2 = num2 - 15;
       }while((10>num1 || num1>50) || (num2<num1));
       
       
       
    system("pause");
    return(0);		
}
