#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>

int numero1, numero2;


int main(){
    setlocale(LC_ALL, "portuguese");
 
    do{
       printf("Digite um n�mero inteiro e depois outro maior\n\n");
       scanf("%i",&numero1);
       scanf("%i",&numero2);
       }
    while(numero2<numero1);
   
    
    do{
       printf("%i-",numero1);
       numero1++;}
    while(numero1!=numero2);
    
    system("pause");
    return(0);	
}
