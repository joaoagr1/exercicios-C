#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>

int contador = 11;


int main(){
    setlocale(LC_ALL, "portuguese");

    while(contador<30){
                       if(contador%2==0){
                                        printf("%i - ",contador);}
                       contador++;
                       };
      
    /*for(contador=11;contador<30;contador++)
    {
     if(contador%2==0){
                      printf("%i - ",&contador);}}
    
    */
    system("pause");
    return(0);	
}
