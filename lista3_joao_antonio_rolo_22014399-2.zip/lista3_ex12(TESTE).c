#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>

char nome[30];
float nota1, nota2, media, porcentagemAprovados, porcentagemReprovados;
float alunosAprovados, alunosReprovados;
int quantidadeAlunos,i;

int main(){
    setlocale(LC_ALL, "portuguese");
    
    printf("Quantos alunos a turma possui?  ");
    scanf("%i",&quantidadeAlunos);
    fflush(stdin);
    
    system("cls");
    
    while(i<quantidadeAlunos){
         i++;
    
         printf("Digite o nome do Aluno[%i]\n\n",i);
         gets(nome);
         fflush(stdin);
         system("cls");
         
         
         
         
         printf("Digite a nota[1] do aluno[%i]\n\n",i);
         scanf("%f",&nota1);
         fflush(stdin);
         system("cls");
         do{ 
         if(nota1>10 || nota1<0){
                printf("Insira um Valor v�lido para a nota[1] do aluno[%i]\n\n",i);
                scanf("%f",&nota1);
                fflush(stdin);
                system("cls");}
           } while(nota1>10 || nota1<0);
                
                
                
    
         printf("Digite a nota[2] do aluno[%i]\n\n",i);
         scanf("%f",&nota2);
         fflush(stdin);
         system("cls");
         do{
         if(nota2>10 || nota2<0){
                printf("Insira um Valor v�lido para a nota[2] do aluno[%i]\n\n",i);
                scanf("%f",&nota2);
                fflush(stdin);
                system("cls");}
           } while(nota2>10 || nota2<0);
           
           media=(nota1+nota2)/2;
           
           if(media>=6){alunosAprovados++;
           }else{alunosReprovados++;}
                
                
           }//fechamento do while pai
    
           porcentagemAprovados=(alunosAprovados*100)/quantidadeAlunos;
           porcentagemReprovados=(alunosReprovados*100)/quantidadeAlunos;
           
           system("cls");
           
           printf("Porcentagem de Alunos Aprovados: %.2f%\n", porcentagemAprovados);
           printf("Porcentagem de Alunos Reprovados: %.2f%\n", porcentagemReprovados);
    
    
    system("pause");
    return(0);	
}
