#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>


int numero;

int main(){
    setlocale(LC_ALL, "portuguese");
    
 for(numero=1; numero<50; numero++){
               if(numero%2!=0){
               printf("%i ",numero);}}
    
    system("pause");
    return(0);	
}

