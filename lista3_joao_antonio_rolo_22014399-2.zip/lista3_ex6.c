#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>

int idade;
char sexo;


int main(){
    setlocale(LC_ALL, "portuguese");
    
                      do{
                         printf("Insira seu sexo m/f\n\n");
                         scanf("%c",&sexo);
                         fflush(stdin);
                         system("cls");
                         if(sexo!= 'm' && sexo!= 'f'){
                             
                              
                         printf("(Insira um sexo v�lido [f/m])\n\n");
                         scanf("%i",&idade);
                         fflush(stdin);}}
                         while(sexo!= 'm' && sexo!= 'f');
          
          
          system("cls");
          
                      do{
                         printf("Insira sua Idade\n\n");
                         scanf("%i",&idade);
                         fflush(stdin);
                         system("cls");
                         if(100<idade || idade<10){
                                        
                                        
                         printf("(Insira uma idade V�lida)\n\n");
                         scanf("%i",&idade);
                         fflush(stdin);}}
                         while(100<idade || idade<10);
           
    
    
    
    
    
    
    
    system("pause");
    return(0);	
}
