//2) Solicitar o nome e idade de 3 pessoas (utilize a estrutura WHILE)
#include <stdlib.h> 
#include <stdio.h>
#include <conio.c>
#include <locale.h>

char name[50];
int age, cont;

int main() {
setlocale(LC_ALL, "portuguese");

while (cont<3) {  

   cont += 1;
   printf("Informe seu nome: \n");
   gets(name);
   fflush(stdin);
   
   printf("Informe sua idade: \n");
   scanf("%i",&age);
   fflush(stdin);
}

system("pause");
return 0;       
}
