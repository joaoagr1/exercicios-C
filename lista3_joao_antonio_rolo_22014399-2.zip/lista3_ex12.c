#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>

int alunosAprovados, alunosReprovados, quantidadeAlunos, i=1;
float nota1, nota2, media;
char nome[20];

int main(){
    setlocale(LC_ALL, "portuguese");
    
    printf("[Bem vindo ao sistema de lan�amento de notas]\n\n");
    printf("Quantos alunos a sala possui?  ");
    scanf("%i",&quantidadeAlunos);
    fflush(stdin);
    system("cls");
    
    while(i<quantidadeAlunos){
                               printf("Digite o nome do aluno [%i]\n\n",i);
                               gets(nome);
                               fflush(stdin);
                               system("cls");
                               
                               do{
                               printf("Digite a nota[1] do aluno[%i]\n\n",i);
                               scanf("%d",&nota1);
                               fflush(stdin);
                               system("cls");
                               
                               if(nota1>10 || nota1<0){
                                           printf("Insira um valor v�lido para nota1 do aluno [%i] [1-10]\n\n",i);}
                               system("cls");}while(nota1<0 || nota1>10);
                               
                               
                               do{
                               printf("Digite a nota[2] do aluno [%i]\n\n",i);
                               scanf("%d",&nota2);
                               fflush(stdin);
                               system("cls");
                               
                               if(nota2>10 || nota2<0){
                                           printf("Insira um valor v�lido para nota2 do aluno [%i] [1-10]\n\n",i);}
                               system("cls");} 
                               while(nota2<0 || nota2>10);
                               
media = (nota1+nota2)/2;
if(media>=6){
             alunosAprovados++;
             }else{alunosReprovados++;}
                               
                               
                               
                               
                               
                               
 i++;   
    
}
    system("pause");
    return(0);	
}
