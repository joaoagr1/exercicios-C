#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>
#include <string.h>

int idade, maiorIdade,i;
char nome[20], maisVelho[20];

int main(){
    setlocale(LC_ALL, "portuguese");
    
    while(i<5){
               i++;
               
               printf("[%i] Insira o nome de uma pessoa:\n",i);
               gets(nome);
               fflush(stdin);
               system("cls");
               
               printf("Insira a idade dessa pessoa\n");
               scanf("%i",&idade);
               fflush(stdin);
               system("cls");
               
               if(idade>maiorIdade){
                                    maiorIdade=idade;
                                    strcpy(maisVelho,nome);}
               }
               
               printf("A pessoa mais velha se chama %s\n",maisVelho);
               printf("E tem %i anos\n",maiorIdade);
    
    
    
    system("pause");
    return(0);	
}
