#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>

char escolha, nome[30], sexo;
int numero, idade, aux, denominador = 1;
float media;


int main(){
    setlocale(LC_ALL, "portuguese");
    
    while(escolha!='n'){
                        
            printf("Insira seu nome\n\n");
            gets(nome);
            fflush(stdin);
            
            system("cls");
            
            printf("Digite sua idade\n\n");
            scanf("%i",&idade);
            fflush(stdin);
            
            system("cls");
            
            printf("Informeu seu sexo [m/f]\n\n");
            scanf("%c",&sexo);
            fflush(stdin);
            system("cls");
            
            if(sexo = 'f'){
                    aux = aux + idade;
                    denominador++;}
            
            printf("Deseja continuar cadastrando valores?[s/n]\n\n");
            scanf("%c",&escolha);
            fflush(stdin);
            system("cls");}
            
            system("cls");
            
            media = aux / denominador;
            
            printf("A m�dia da idade das mulheres �: %.2f  ",media);
                        
    
    
    
    
    system("pause");
    return(0);	
}
