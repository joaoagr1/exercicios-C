#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>
#include <string.h>

int mes, dia, signo;

int main(){
    setlocale(LC_ALL, "portuguese");
    
    printf("Digite o seu M�s de nascimento (1-12):  ");
    scanf("%i",&mes);
    fflush(stdin);
    
    printf("Digite o dia em que voc� nasceu:  ");
    scanf("%i",&dia);
    fflush(stdin);
    system("cls");
    
    system("cls");
    
    if(mes==1){
               if(dia>=21){printf("Seu signo � �quario\n\n");
               }else{printf("Seu signo � Capric�rnio\n\n");}}
               
    if(mes==2){
               if(dia<=20){printf("Seu signo � Peixes\n\n");
               }else{printf("Seu signo � �quario\n\n");}}
               
    if(mes==3){
               if(dia>=21){printf("Seu signo � �ries\n\n");
               }else{printf("Seu signo � Peixes\n\n");}}
               
    if(mes==4){
               if(dia>=21){printf("Seu signo � Touro\n\n");
               }else{printf("Seu signo � �ries\n\n");}}
    if(mes==5){
               if(dia>=21){printf("Seu signo � G�meos\n\n");
               }else{printf("Seu signo � Touro\n\n");}}
               
    if(mes==6){
               if(dia>=21){printf("Seu signo � C�ncer\n\n");
               }else{printf("Seu signo � G�meos\n\n");}}
              
    if(mes==7){
               if(dia>=22){printf("Seu signo � Le�o\n\n");
               }else{printf("Seu signo � C�ncer\n\n");}} 
               
               
     if(mes==8){
               if(dia>=23){printf("Seu signo � Virgem\n\n");
               }else{printf("Seu signo � Le�o\n\n");}}
               
               
     if(mes==9){
               if(dia>=23)printf("Seu signo � Libra\n\n");
               }else{printf("Seu signo � Virgem\n\n");}   
               
               
    if(mes==10){
               if(dia>=23){printf("Seu signo � Escorpi�o\n\n");
               }else{printf("Seu signo � Libra\n\n");}} 
               
               
    if(mes==11){
               if(dia>=22){printf("Seu signo � Sagit�rio\n\n");
               }else{printf("Seu signo � Escorpi�o\n\n");}} 
               
    if(mes==12){
               if(dia>=22){printf("Seu signo � Capric�rnio\n\n");
               }else{printf("Seu signo � Sagit�rio\n\n");}} 
               
               
               
               
               
               
               
                           
               
               
    
    system("pause");
    return(0);	
}
