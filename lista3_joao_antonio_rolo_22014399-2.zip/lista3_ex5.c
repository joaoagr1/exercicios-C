#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>

int numero=30;

int main(){
    setlocale(LC_ALL, "portuguese");
    
    while(numero!=4){printf("%i ",numero );
    numero--;}
    
    system("pause");
    return(0);	
}
