#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>
#include <string.h>

int contador, idade, filhos,quantidadeHomens,idadeTotalMulheresSemFilhos,denominadorMulheresSemfilhos;
int quantidadeDeMulheresEntrevistadas, maiorIdade, menorIdade;
char nome[20], sexo, maisVelho[20], maisnovo[20];
float percentualDeHomens,mediaIdadeMulheresSemFilho;

int main(){
    setlocale(LC_ALL, "portuguese");
    
    while(contador<12){
    contador++;
    
    printf("[%i] Digite seu nome: ",contador);
    gets(nome);
    fflush(stdin);
    //system("cls");
    
    
    
    printf("[%i] Digite sua idade: ",contador);
    scanf("%i",&idade);
    fflush(stdin);
    //system("cls");
    
   
    printf("[%i] Digite seu sexo [m/f]: ",contador);
    scanf("%c",&sexo);
    fflush(stdin);
    //system("cls");
     do{
    if(sexo!='m' && sexo!='f'){
                 printf("Insira um valor correto: ");
                 scanf("%c",&sexo);
                 fflush(stdin);}
    }while(sexo!='m' && sexo!='f');
    
    printf("[%i] Quantos filhos voc� tem?: ",contador);
    scanf("%i",&filhos);
    fflush(stdin);
    system("cls");
    
    if(sexo=='m'){quantidadeHomens++;}
    if(sexo=='f' && filhos==0){idadeTotalMulheresSemFilhos=idadeTotalMulheresSemFilhos + idade;
                              denominadorMulheresSemfilhos++;}
    if(sexo=='f'){quantidadeDeMulheresEntrevistadas++;}
    if(idade>maiorIdade){maiorIdade=idade;
                         strcpy(maisVelho,nome);}
    if(idade<menorIdade){menorIdade=idade;
                         strcpy(maisNovo,nome);}
    
}//fecha while pai

percentualDeHomens=(quantidadeHomens*100)/12;
mediaIdadeMulheresSemFilho=(denominadorMulheresSemfilhos*100)/12;

printf("Percentual de homens na pesquisa: %.2f\n",percentualDeHomens);
printf("M�dia de Idade das mulheres sem filhos: %.2f\n",mediaIdadeMulheresSemFilho);
printf("Nome da idade da pessoa mais jovem:\n");
printf("Quantidade de mulheres entrevistadas: %.2i\n",quantidadeDeMulheresEntrevistadas);
printf("Nome e idade do(a) mais novo(a) entrevistado(a): %s",maisNovo);
priintf("Nome e idade do(a) mais velho(a) entrevistado(a): %s",maisVelho);
    
    
    
    
    
    
    
    
     system("pause");
    return(0);	
}
