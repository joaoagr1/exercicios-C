#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>

int contador, idade, filhos,quantidadeHomens,idadeTotalMulheresSemFilhos,denominadorMulheresSemfilhos,quantidadeDeMulheresEntrevistadas;
char nome[20], sexo;
float percentualDeHomens,mediaIdadeMulheresSemFilho;

int main(){
    setlocale(LC_ALL, "portuguese");
    
    while(contador<12){
    contador++;
    
    printf("[%i] Digite seu nome: ",contador);
    gets(nome);
    fflush(stdin);
    //system("cls");
    
    
    
    printf("[%i] Digite sua idade: ",contador);
    scanf("%i",&idade);
    fflush(stdin);
    //system("cls");
    
   
    printf("[%i] Digite seu sexo [m/f]: ",contador);
    scanf("%c",&sexo);
    fflush(stdin);
    //system("cls");
     do{
    if(sexo!='m' && sexo!='f'){
                 printf("Insira um valor correto: ");
                 scanf("%c",&sexo);
                 fflush(stdin);}
    }while(sexo!='m' && sexo!='f');
    
    printf("[%i] Quantos filhos voc� tem?: ",contador);
    scanf("%i",&filhos);
    fflush(stdin);
    system("cls");
    
    if(sexo=='m'){quantidadeHomens++;}
    if(sexo=='f' && filhos==0){idadeTotalMulheresSemFilhos=idadeTotalMulheresSemFilhos + idade;
                              denominadorMulheresSemfilhos++;}
    if(sexo=='f'){quantidadeDeMulheresEntrevistadas++;}
    
}//fecha while pai

percentualDeHomens=(quantidadeHomens*100)/12;
mediaIdadeMulheresSemFilho=(denominadorMulheresSemfilhos*100)/12;

printf("Percentual de homens na pesquisa: %.2f\n",percentualDeHomens);
printf("M�dia de Idade das mulheres sem filhos: %.2f\n",mediaIdadeMulheresSemFilho);
printf("Nome da idade da pessoa mais jovem:\n");
printf("Quantidade de mulheres entrevistadas: %.2i\n",quantidadeDeMulheresEntrevistadas);
    
    
    
    
    
    
    
    
     system("pause");
    return(0);	
}
