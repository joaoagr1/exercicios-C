#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.c>



int numero,auxiliar,i;



float media;

int main(){
    setlocale(LC_ALL, "portuguese");

    for(i=1;i<11;i++){
                       printf("Digite um n�mero\n\n");
                       scanf("%i",&numero);
                       fflush(stdin);
                       system("cls");
                       
                       if(numero%2==0){
                                       printf("O n�mero digitado � par\n\n");}
                                       else{printf("O n�mero digitado � impar\n\n");
                                       }
                                       
                       auxiliar=auxiliar+numero;
                       media = auxiliar / i;
                       }
                       
                       printf("A m�dia dos valores digitados � igual a %f",media);
                       




system("pause");
    return(0);	
}
